# Zenodo upload guide (about 15 minutes)

You need to do this step yourself, because it uses your own account.

1. Go to https://zenodo.org and log in. Use **"Log in with ORCID"** (your ORCID: 0009-0001-6243-1709).
2. Click **New upload**.
3. Upload the file **India_Govt_Blockchain_Dataset_v1.1.0.zip** (it contains everything).
4. Fill in the form by copying the fields below:

| Zenodo field | Value to paste |
|---|---|
| Resource type | Dataset |
| Title | Blockchain in Indian Government Administration: A Project-Level Dataset (2017–2026) |
| Creators | Mondal, Santanu — ORCID 0009-0001-6243-1709 — Pondicherry University |
| Description | Standardised (Frictionless Data Package), source-linked inventory of 117 blockchain / distributed-ledger initiatives by Indian public bodies: Union ministries, all 28 States and 8 Union Territories (searched individually), districts, municipal bodies, regulators (RBI, SEBI, TRAI), the Supreme Court, the Election Commission, statutory boards and PSUs. Each project records implementing body, purpose, platform, partner, lifecycle stage with dated events (announced, pilot, live, latest update), scale, TOE-coded challenges and links to 339 sources. Nine coded variables (level of government, use-case, chain type, platform, service type, start year, scale tier, problem addressed, evidence score 1–5) support analysis. Includes a time series of the NIC blockchain platform by department (Jul 2024 – Oct 2026; 11.31 crore documents and 47.76 crore verifications on 14 Oct 2026), ISO 3166-2 and LGD codes for all 36 jurisdictions, a validation/build tool, SQLite and Excel editions, a dashboard, codebook, reliability check (Cohen's kappa), excluded items, and draft RTI applications. Prepared with AI assistance (Claude, Anthropic); reviewed by the author. |
| Version | 1.1.0 |
| Language | English |
| Keywords | blockchain; distributed ledger technology; e-governance; India; National Blockchain Framework; NIC; land records; digital certificates; CBDC; public sector; TOE framework; Frictionless Data Package |
| Publication date | (upload date) |
| Licence | Creative Commons Attribution 4.0 International |
| Related works (optional) | "Is described by" → the DOI of your data paper (add later) |

5. Click **Publish**. Zenodo gives you a DOI (e.g. 10.5281/zenodo.1234567).
6. Put the DOI into `CITATION.cff`, `README.md` and the data paper ("Data accessibility" section).

**Updating later:** Open the record and click **New version** each time you add RTI replies or a new NIC dashboard snapshot. The old DOI keeps working, and a "concept DOI" always points to the latest version.

**First upload?** Upload v1.1.0 directly (there is no need to upload v1.0.0 first).
